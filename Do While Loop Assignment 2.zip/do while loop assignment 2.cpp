#include <iostream>
using namespace std;

//137187 - Asher Yisrael Kutswa

int main(){
	//Initialize x and i with the values 20 and 0 respectively, x is our counter and i is our sum.
	int x = 20;
	int i = 0;
	//The do statement.
	do{
		i += x;
	//Increment the value x.
		x++;
	}
	//If x is less than or equal to 25
	while(x<=25);
	cout<<"The sum of values between 20 and 25 is : "<<i;
	return 0;	
}
