#include <iostream>
using namespace std;

//137187 - Asher Yisrael Kutswa

int main(){
	//Declare the integer x.
	int x;
	//Initialize the integer x as the value 12.
	//If x is less than or equal to 28.
	//Increment x.
	for(int x=12; x <= 28; x++){
		//If the number is divisible by 2 then print in the console
	if (x % 2 == 0){
		cout<< x << "\n";
	}
	}
	return 0;
}
