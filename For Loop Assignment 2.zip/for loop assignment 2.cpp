#include <iostream>
using namespace std;

//137187 - Asher Yisrael Kutswa

int main(){
	//Declare the integer x.
	int x;
	//Initialize the integer x as the value 0.
	int i=0;
	//Initialize the integer x as the value 12.
	//If x is less than or equal to 28.
	//Increment x.
	for(int x=20; x <= 25; x++){
	i += x;
	}
	//Output of the sum.
	cout<<"The sum of values between 20 and 25 is : "<<i;
	return 0;
}
