#include <iostream>
using namespace std;

//137187 - Asher Yisrael Kutswa

int main(){
	//Initialize  x with the value 12
	int x=12;
	//If x is less than or equal to 28
	while(x<=28){
		//If the number is divisible by 2 then print in the console
	if (x % 2 == 0){
		cout<< x << "\n";
	}
	//Increment the value x
	x++;
	}
	
	return 0;
}
